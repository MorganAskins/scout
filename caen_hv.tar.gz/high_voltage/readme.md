Install in the following order:

- CAENGECO is optional. cd into directory and run ./install.sh with permissions
- CAENVMELib: cd into lib then sudo ./install_x64
- CAENUSBdrv: cd into directory then make && make install (as root)
- CAENComm: cd into directory/lib and sudo ./install_x64
- CAENHVWrapper: cd into directory, sudo ./install.sh
